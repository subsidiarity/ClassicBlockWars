using System.Collections;
using UnityEngine;

public class LevelSpawner : MonoBehaviour
{
	public Transform spawnPointRoad;

	public Transform spawnPointHill;

	public Transform playerCar;

	private void Start()
	{
	}

	private void Update()
	{
	}

	// TODO: What the fuck is this?
	private void OnGUI()
	{
		if (GUILayout.Button("Respawn Road"))
		{
			playerCar.rigidbody.velocity = Vector3.zero;
			playerCar.rigidbody.freezeRotation = true;
			playerCar.position = spawnPointRoad.position;
			playerCar.rotation = spawnPointRoad.rotation;
			StartCoroutine("ResetRotation");
		}
		if (GUILayout.Button("Respawn Hill"))
		{
			playerCar.rigidbody.velocity = Vector3.zero;
			playerCar.rigidbody.freezeRotation = true;
			playerCar.rigidbody.rotation = Quaternion.identity;
			playerCar.position = spawnPointHill.position;
			playerCar.rotation = spawnPointHill.rotation;
			StartCoroutine("ResetRotation");
		}
	}

	private IEnumerator ResetRotation()
	{
		yield return new WaitForSeconds(0.5f);
		playerCar.rigidbody.freezeRotation = false;
	}
}
